SET DATEFORMAT dmy;
BULK INSERT a1701638.a1701638.[Entregan]
   FROM 'e:\wwwroot\a1701638\entregan.csv'
   WITH 
      (
         CODEPAGE = 'ACP',
         FIELDTERMINATOR = ',',
         ROWTERMINATOR = '\n'
      )