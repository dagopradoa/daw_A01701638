BULK INSERT a1701638.a1701638.[Proveedores]
   FROM 'e:\wwwroot\a1701638\proveedores.csv'
   WITH 
      (
         CODEPAGE = 'ACP',
         FIELDTERMINATOR = ',',
         ROWTERMINATOR = '\n'
      )