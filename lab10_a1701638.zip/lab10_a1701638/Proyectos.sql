BULK INSERT a1701638.a1701638.[Proyectos]
   FROM 'e:\wwwroot\a1701638\proyectos.csv'
   WITH 
      (
         CODEPAGE = 'ACP',
         FIELDTERMINATOR = ',',
         ROWTERMINATOR = '\n'
      )