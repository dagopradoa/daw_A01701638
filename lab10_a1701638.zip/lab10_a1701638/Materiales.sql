BULK INSERT a1701638.a1701638.[Materiales]
   FROM 'e:\wwwroot\a1701638\materiales.csv'
   WITH 
      (
         CODEPAGE = 'ACP',
         FIELDTERMINATOR = ',',
         ROWTERMINATOR = '\n'
      )
