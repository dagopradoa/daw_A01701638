SELECT * 
FROM materiales 

SELECT * 
FROM materiales 
WHERE clave=1000 

SELECT clave,rfc,fecha 
FROM entregan 

SELECT * 
FROM materiales,entregan 
WHERE materiales.clave = entregan.clave 

SELECT * 
FROM Entregan E, Proyectos P 
WHERE E.Numero < = P.Numero

(SELECT * 
FROM entregan 
WHERE clave=1450) 
union 
(SELECT * 
FROM entregan
WHERE clave=1300)

SELECT *
FROM Entregan
WHERE clave=1450
OR clave=1300

(SELECT clave 
FROM entregan 
WHERE numero=5001) 
intersect 
(select clave 
FROM entregan 
WHERE numero=5018) 

(SELECT * 
FROM entregan) 
MINUS
(SELECT * 
FROM entregan 
WHERE clave=1000) 

SELECT * 
FROM entregan,materiales

SELECT *
FROM Entregan

SELECT *
FROM Materiales

SELECT Descripcion
FROM Entregan E, Materiales M
WHERE E.Clave=M.Clave

SELECT DISTINCT Descripcion
FROM Entregan E, Materiales M
WHERE E.Clave=M.Clave

SELECT DISTINCT Descripcion
FROM Entregan E, Materiales M
WHERE E.Clave=M.Clave
ORDER BY Descripcion DESC

SELECT * 
FROM Materiales 
WHERE Descripcion LIKE 'Var%' 

DECLARE @foo varchar(40); 
DECLARE @bar varchar(40); 
SET @foo = '�Que resultado'; 
SET @bar = ' ���??? ' 
SET @foo += ' obtienes?'; 
PRINT @foo + @bar; 

SELECT RFC 
FROM Entregan 
WHERE RFC LIKE '[A-D]%';
 
SELECT RFC 
FROM Entregan 
WHERE RFC LIKE '[^A]%'; 

SELECT Numero 
FROM Entregan 
WHERE Numero LIKE '___6'; 

SELECT RFC,Cantidad, Fecha,Numero 
FROM [Entregan] 
WHERE [Numero] Between 5000 and 5010 AND 
Exists ( SELECT [RFC] 
FROM [Proveedores] 
WHERE RazonSocial LIKE 'La%' and [Entregan].[RFC] = [Proveedores].[RFC]) 

SELECT TOP 2 * FROM Proyectos

SELECT TOP Numero FROM Proyectos

ALTER TABLE materiales ADD PorcentajeImpuesto NUMERIC(6,2); 
UPDATE materiales SET PorcentajeImpuesto = 2*clave/1000;

SELECT SUM((M.Costo+M.PorcentajeImpuesto)*Cantidad)as Total
FROM Entregan, (SELECT Costo, Clave, PorcentajeImpuesto FROM Materiales)M
WHERE Entregan.Clave = M.Clave

SELECT M.Clave, M.Descripcion
FROM Entregan E, Proveedores P, Materiales M
WHERE E.Clave=M.Clave
AND P.RFC=E.RFC
AND P.RazonSocial = 'Acme tools'

SET DATEFORMAT dmy
SELECT P.RFC
FROM Proveedores P, Entregan E
WHERE P.RFC=E.RFC
AND Fecha between '01/01/2000' AND '31/12/2000'
AND Cantidad>'299'

SELECT SUM(Cantidad)
FROM Entregan 

SET DATEFORMAT dmy
SELECT TOP 1 clave
FROM entregan
WHERE Fecha between '01/01/2001' and '31/12/2001'
ORDER BY cantidad DESC

SELECT M.Descripcion
FROM Materiales M
WHERE Descripcion LIKE '%ub%'

SELECT P.Denominacion, SUM((M.Costo+m.Costo*M.PorcentajeImpuesto/100)*Cantidad) AS 'TotalPagar'
FROM Entregan E, Materiales M, Proyectos P
WHERE M.Clave=E.Clave 
AND P.Numero=E.Numero
GROUP BY p.Denominacion

CREATE VIEW ProyectoTelevisa AS (
SELECT p.denominacion, pr.RFC, pr.RazonSocial
FROM Entregan e, proyectos p, Proveedores pr
WHERE p.numero=e.numero 
AND pr.RFC=e.RFC 
AND p.Denominacion='Educando en Coahuila')
SELECT * 
FROM ProyectoTelevisa

SELECT DISTINCT P.Denominacion, Pr.RFC, Pr.RazonSocial
FROM Entregan E, proyectos P, Proveedores Pr
WHERE P.Numero=E.Numero 
AND Pr.RFC=E.RFC 
AND p.Denominacion='Televisa en acci�n' 
AND pr.RazonSocial not in (
	SELECT pr.RazonSocial
	FROM Entregan e, proyectos p, Proveedores pr
	WHERE p.numero=e.numero and pr.RFC=e.RFC 
	AND p.Denominacion='Educando en Coahuila')

SELECT M.Costo, M.Clave
FROM Entregan E, proyectos P, Proveedores Pr, materiales M
WHERE p.numero=e.numero 
AND Pr.RFC=E.RFC 
AND M.Clave = E.Clave
AND P.Denominacion='Televisa en acci�n' 
AND Pr.RFC in (
	SELECT Pr.RFC
	FROM Entregan E, proyectos P, Proveedores Pr, Materiales M
	WHERE P.Numero=E.Numero 
	AND Pr.RFC=E.RFC 
	AND M.Clave = E.Clave
	AND P.Denominacion='Educando en Coahuila')